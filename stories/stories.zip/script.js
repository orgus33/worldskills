const fetchJson = async () => {
    const response = await fetch("people.json");
    return await response.json();
}

const body = document.querySelector("body");
const story = document.querySelector(".story");

const closeStory = (interval) => {
    clearInterval(interval);
    body.classList.remove("overflow-hidden");
    story.classList.add("hidden")
}


const openStory = (people) => {
    const avatarStory = story.querySelector(".avatar-story");
    const usernameStory = story.querySelector(".username-story");
    const timeStory = story.querySelector(".time-story");
    const closeStoryBtn = story.querySelector(".close-story");
    const storyImg = story.querySelector(".story-img");
    const slidesContainer = story.querySelector(".slides");
    let interval;

    // Formatter la date
    //const sinceDate = new Intl(people.slides[0].date)

    const testDate = new Date(people.slides[0].date)
    const nowDate = new Date()
    const sinceDate = new Date(nowDate.getTime() - testDate.getTime());

    // console.log(Intl.DateTimeFormat().format(sinceDate))
    //
    // const duration = {
    //     days: sinceDate.getUTCDay(),
    //     hours: sinceDate.getHours(),
    //     minutes: sinceDate.getMinutes(),
    //     seconds: sinceDate.getSeconds(),
    // };
    //
    // console.log(new Intl.DurationFormat("fr-FR", { style: "long" }).format(duration));

    avatarStory.src = people.user.avatar;
    usernameStory.innerText = people.user.firstName + " " + people.user.lastName;
    timeStory.innerText = sinceDate.getDay() + " " + "d"
    storyImg.src = people.slides[0].image

    closeStoryBtn.addEventListener("click", () => closeStory(interval));


    // gestion des sliders

    slidesContainer.innerHTML = "";

    people.slides.forEach((slide, i) => {
        const slideContainer = document.createElement("div");
        slideContainer.className = "h-1 rounded-xl w-full bg-gray-400 relative overflow-hidden"
        slideContainer.id = i;

        const progressBar = document.createElement("div");
        progressBar.className = "progress-bar rounded-xl absolute left-0 top-0 bottom-0 bg-gray-50"

        slideContainer.appendChild(progressBar);
        slidesContainer.append(slideContainer);
    })

    const sliders = story.querySelectorAll(".progress-bar")
    let currentSlider = 0
    const storyDuration = 5000

    sliders[currentSlider].animate([
        {width: "0"},
        {width: "100%"},
    ], {
        duration: storyDuration,
        iterations: 1,
        fill: "forwards"
    })

    currentSlider++;

    if (slidesContainer.children.length > 1) {
        interval = setInterval(() => {
            if ( currentSlider === slidesContainer.children.length - 1) {
                clearInterval(interval);

                setTimeout(() => {
                    closeStory();
                }, storyDuration)
            }

            storyImg.src = people.slides[currentSlider].image

            sliders[currentSlider].animate([
                {width: "0"},
                {width: "100%"},
            ], {
                duration: storyDuration,
                iterations: 1,
                fill: "forwards"
            })
            currentSlider++;
        }, storyDuration)
    } else {
        setTimeout(() => {
            closeStory();
        }, storyDuration)
    }



    body.classList.add("overflow-hidden");
    story.classList.remove("hidden")

}


document.addEventListener("DOMContentLoaded", async () => {

    // Initialiser le front
    const people = await fetchJson();

    const peopleContainer = document.querySelector(".people-container");

    people.forEach(person => {
        const container = document.createElement("div");
        container.className = "avatar relative hover:scale-125 duration-200";

        const img = document.createElement("img");
        img.className = "object-cover rounded-full overflow-hidden border-5 border-gray-200 cursor-pointer hover:border-gray-500  ";
        img.src = person.user.avatar

        container.appendChild(img);

        peopleContainer.append(container)

        container.addEventListener("click", () => openStory(person))
    })


})


